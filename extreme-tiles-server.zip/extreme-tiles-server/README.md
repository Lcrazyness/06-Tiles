# extreme-tiles-server

Backend for Extreme Tiles. Two jobs:

1. **Level library** — REST API backed by Postgres. This is the real version
   of what the game's `storage.js` currently fakes with `localStorage`.
2. **Battle relay** — a Socket.IO room that relays presence/challenge/progress
   messages between players in real time, across devices (unlike the
   game's current `BroadcastChannel` version, which only works between tabs
   in the same browser).

## Run it locally

```bash
npm install
cp .env.example .env     # then point DATABASE_URL at a real Postgres
npm start                # listens on :3000
```

You need *some* Postgres to point `DATABASE_URL` at, even locally — a free
[Neon](https://neon.tech) or [Supabase](https://supabase.com) database
works fine for local dev if you don't want to install Postgres yourself.

## API

| Method | Path                    | Body                          | Notes                                  |
|--------|--------------------------|--------------------------------|-----------------------------------------|
| GET    | `/api/levels`            | —                              | Query: `?search=&tab=recent\|trending\|rated\|featured` |
| GET    | `/api/levels/:id`        | —                              | Single level                            |
| POST   | `/api/levels`            | level object (see below)       | Publish                                 |
| POST   | `/api/levels/:id/play`   | —                               | Increment play count                    |
| POST   | `/api/levels/:id/rate`   | `{ "stars": 1-5 }`              | Add a rating                            |
| DELETE | `/api/levels/:id`        | —                               | Remove a level                          |

Level object shape (matches `buildLevelObject()` in the game's `storage.js`):

```json
{
  "name": "My Level",
  "author": "SomeName",
  "data": [ { "lane": 0, "time": 1.2, "isHold": false, "holdDuration": 0 } ],
  "effects": [],
  "lives": 3,
  "fps": 60,
  "audioOffset": 0,
  "disableHolds": false,
  "difficulty": "Normal"
}
```

Battle messages go over a Socket.IO event called `arena_message`, and use
the same `type` field the client already speaks (`presence`, `presence_bye`,
`quick_match_seek`, `challenge`, `challenge_accept`, `challenge_decline`,
`progress`, `finish`). The server just relays them to every other connected
client — see `src/arena.js`.

## Deploying to Render

### Option A — one-click Blueprint (recommended)

1. Push this folder to its own new GitHub repo (steps below).
2. In the Render dashboard: **New → Blueprint**, pick that repo. Render reads
   `render.yaml` and offers to create both the web service *and* a free
   Postgres database, already wired together via `DATABASE_URL`.
3. Before clicking **Apply**, edit the `ALLOWED_ORIGIN` value in the
   Blueprint preview (or in the dashboard afterward) to your game's real
   URL — e.g. `https://yourname.github.io`.
4. Click **Apply**. First deploy takes a few minutes.

### Option B — manual

1. **New → PostgreSQL**, free plan, any name. Copy its "Internal Database URL".
2. **New → Web Service**, connect the repo, runtime **Node**, build command
   `npm install`, start command `npm start`.
3. Add environment variables: `DATABASE_URL` (paste the internal URL from
   step 1) and `ALLOWED_ORIGIN` (your game's URL).
4. Deploy.

### Pushing this folder to a new repo

```bash
cd extreme-tiles-server        # this folder
git init
git add -A
git commit -m "Initial backend"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/extreme-tiles-server.git
git push -u origin main
```

(Create the empty repo on GitHub first — **New repository**, no README/gitignore,
since this folder already has them — then run the commands above.)

### Things to know about Render's free tier (checked against Render's own docs)

- Free **web services** spin down after 15 minutes with no incoming traffic.
  The next request wakes it back up but takes ~30–60 seconds — expect a slow
  first load/reconnect after idle time, not an error.
- Free **Postgres** databases are capped at 1 GB and **expire 30 days after
  creation** (with a 14-day grace period to upgrade before deletion). For a
  hobby project that's fine to recreate periodically; for anything longer-lived,
  either upgrade the database plan on Render, or point `DATABASE_URL` at a
  permanent free Postgres from Neon or Supabase instead — nothing else in this
  code needs to change.

## Wiring the game up to this

Once deployed, you'll have a URL like `https://extreme-tiles-server.onrender.com`.
The frontend doesn't call it yet — `storage.js`'s community-level functions and
`battle.js`'s arena transport still use `localStorage`/`BroadcastChannel`. Swapping
them to call this API/socket instead is a frontend change (fetch the URL above
for `/api/levels`, connect Socket.IO to the same URL for battles) — happy to do
that next once this is deployed and you have the URL.

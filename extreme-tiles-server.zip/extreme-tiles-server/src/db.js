// db.js — one Postgres pool for the whole process, plus a schema bootstrap
// that runs on boot so there's no separate migration step for this scale
// of project. Render injects DATABASE_URL automatically when you link a
// Render Postgres instance to this web service.

const { Pool } = require('pg');

if (!process.env.DATABASE_URL) {
  console.warn('DATABASE_URL is not set — the server will start but every /api/levels call will fail until it is.');
}

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  // Render's managed Postgres requires SSL; local Postgres during development usually doesn't use it.
  ssl: process.env.DATABASE_URL && !process.env.DATABASE_URL.includes('localhost')
    ? { rejectUnauthorized: false }
    : false
});

async function initSchema() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS levels (
      id             TEXT PRIMARY KEY,
      name           TEXT NOT NULL,
      author         TEXT NOT NULL DEFAULT 'Unknown',
      data           JSONB NOT NULL,
      effects        JSONB NOT NULL DEFAULT '[]',
      lives          INTEGER NOT NULL DEFAULT 3,
      fps            INTEGER NOT NULL DEFAULT 60,
      audio_offset   INTEGER NOT NULL DEFAULT 0,
      disable_holds  BOOLEAN NOT NULL DEFAULT false,
      difficulty     TEXT NOT NULL DEFAULT 'Normal',
      ratings        JSONB NOT NULL DEFAULT '[]',
      plays          INTEGER NOT NULL DEFAULT 0,
      created_at     BIGINT NOT NULL
    );
  `);
}

module.exports = { pool, initSchema };

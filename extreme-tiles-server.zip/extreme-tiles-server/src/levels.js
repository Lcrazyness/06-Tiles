// levels.js — REST API for the level library. This is the real version of
// what storage.js's getCommunityLevels()/setCommunityLevels() fake with
// localStorage on the client today.

const express = require('express');
const crypto = require('crypto');
const { pool } = require('../src/db');

const router = express.Router();

function avg(arr) { return arr && arr.length ? arr.reduce((a, b) => a + b, 0) / arr.length : 0; }

function rowToLevel(row) {
  return {
    id: row.id,
    name: row.name,
    author: row.author,
    data: row.data,
    effects: row.effects,
    lives: row.lives,
    fps: row.fps,
    audioOffset: row.audio_offset,
    disableHolds: row.disable_holds,
    difficulty: row.difficulty,
    ratings: row.ratings,
    plays: row.plays,
    createdAt: Number(row.created_at)
  };
}

// GET /api/levels?search=&tab=recent|trending|rated|featured
router.get('/levels', async (req, res) => {
  try {
    const search = (req.query.search || '').toString();
    const tab = (req.query.tab || 'recent').toString();
    const { rows } = await pool.query(
      `SELECT * FROM levels WHERE name ILIKE $1 OR author ILIKE $1 ORDER BY created_at DESC LIMIT 200`,
      ['%' + search + '%']
    );
    let levels = rows.map(rowToLevel);
    if (tab === 'trending') {
      levels.sort((a, b) => b.plays - a.plays);
    } else if (tab === 'rated') {
      levels.sort((a, b) => avg(b.ratings) - avg(a.ratings));
    } else if (tab === 'featured') {
      levels = levels.filter(l => avg(l.ratings) >= 4 || l.plays >= 5);
      levels.sort((a, b) => avg(b.ratings) - avg(a.ratings));
    }
    res.json(levels);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to load levels' });
  }
});

router.get('/levels/:id', async (req, res) => {
  try {
    const { rows } = await pool.query('SELECT * FROM levels WHERE id = $1', [req.params.id]);
    if (!rows[0]) return res.status(404).json({ error: 'Not found' });
    res.json(rowToLevel(rows[0]));
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to load level' });
  }
});

// POST /api/levels — publish a level. Body shape matches buildLevelObject() in storage.js.
router.post('/levels', async (req, res) => {
  try {
    const b = req.body || {};
    if (!b.name || !Array.isArray(b.data)) return res.status(400).json({ error: 'name and data are required' });
    const id = 'lvl_' + crypto.randomBytes(8).toString('hex');
    await pool.query(
      `INSERT INTO levels (id, name, author, data, effects, lives, fps, audio_offset, disable_holds, difficulty, ratings, plays, created_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,'[]',0,$11)`,
      [
        id, b.name, b.author || 'Unknown', JSON.stringify(b.data), JSON.stringify(b.effects || []),
        b.lives || 3, b.fps || 60, b.audioOffset || 0, !!b.disableHolds, b.difficulty || 'Normal', Date.now()
      ]
    );
    const { rows } = await pool.query('SELECT * FROM levels WHERE id = $1', [id]);
    res.status(201).json(rowToLevel(rows[0]));
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to publish level' });
  }
});

router.post('/levels/:id/play', async (req, res) => {
  try {
    await pool.query('UPDATE levels SET plays = plays + 1 WHERE id = $1', [req.params.id]);
    res.json({ ok: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to register play' });
  }
});

router.post('/levels/:id/rate', async (req, res) => {
  try {
    const stars = parseInt(req.body.stars, 10);
    if (!(stars >= 1 && stars <= 5)) return res.status(400).json({ error: 'stars must be an integer 1-5' });
    await pool.query(`UPDATE levels SET ratings = ratings || $1::jsonb WHERE id = $2`, [JSON.stringify([stars]), req.params.id]);
    res.json({ ok: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to rate level' });
  }
});

router.delete('/levels/:id', async (req, res) => {
  try {
    await pool.query('DELETE FROM levels WHERE id = $1', [req.params.id]);
    res.json({ ok: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to delete level' });
  }
});

module.exports = router;

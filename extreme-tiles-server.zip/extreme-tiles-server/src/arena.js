// arena.js — real-time relay for battle mode. Deliberately mirrors the
// message shape the client already speaks in battle.js (a "type" field:
// presence, presence_bye, quick_match_seek, challenge, challenge_accept,
// challenge_decline, progress, finish) so swapping the client's
// BroadcastChannel/localStorage transport for this one is mostly just
// pointing broadcastArena()/initArenaChannel() at a socket instead.
//
// This is a plain relay, not a matchmaking authority: clients still decide
// who "wins" ties etc. That keeps this file small; if the game grows real
// stakes (rankings, anti-cheat) that logic should move server-side.

const presence = new Map(); // socket.id -> { name, ts }

function attachArena(io) {
  io.on('connection', (socket) => {
    // A newly connected client (e.g. someone who just opened Battle) gets an
    // immediate snapshot of who's already online, instead of waiting up to
    // one heartbeat interval to find out.
    for (const { name, ts } of presence.values()) {
      socket.emit('arena_message', { type: 'presence', name, ts });
    }

    socket.on('arena_message', (msg) => {
      if (!msg || typeof msg.type !== 'string') return;

      if (msg.type === 'presence' && msg.name) {
        presence.set(socket.id, { name: msg.name, ts: Date.now() });
      }
      if (msg.type === 'presence_bye') {
        presence.delete(socket.id);
      }

      // Relay to everyone else. Targeted messages (challenge/accept/decline)
      // carry their own `to`/`matchId` fields that the recipient filters on,
      // same as the BroadcastChannel version did.
      socket.broadcast.emit('arena_message', msg);
    });

    socket.on('disconnect', () => {
      const entry = presence.get(socket.id);
      presence.delete(socket.id);
      if (entry) socket.broadcast.emit('arena_message', { type: 'presence_bye', name: entry.name });
    });
  });
}

module.exports = { attachArena };

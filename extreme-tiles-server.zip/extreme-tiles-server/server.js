// server.js — entry point. Start with `npm start` (or Render runs this for you).

const express = require('express');
const cors = require('cors');
const http = require('http');
const { Server } = require('socket.io');

const { initSchema } = require('./src/db');
const levelsRouter = require('./src/levels');
const { attachArena } = require('./src/arena');

const app = express();

// Set ALLOWED_ORIGIN to your game's real URL once you know it (e.g. your
// GitHub Pages URL). Leaving it unset defaults to "*" for easy local testing,
// but that's too permissive for production — lock it down once deployed.
const allowedOrigin = process.env.ALLOWED_ORIGIN || '*';
app.use(cors({ origin: allowedOrigin }));
app.use(express.json({ limit: '5mb' }));

app.get('/', (req, res) => res.json({ ok: true, service: 'extreme-tiles-server' }));
app.use('/api', levelsRouter);

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: allowedOrigin } });
attachArena(io);

const PORT = process.env.PORT || 3000;

initSchema()
  .then(() => {
    server.listen(PORT, () => console.log('extreme-tiles-server listening on port ' + PORT));
  })
  .catch((err) => {
    console.error('Failed to initialize database schema:', err);
    process.exit(1);
  });
